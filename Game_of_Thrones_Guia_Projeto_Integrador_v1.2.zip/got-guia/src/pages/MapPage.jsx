import { places } from "../data/data";
import { Page } from "./Fundamentals";
export default function MapPage({navigate}) {
 return <Page title="Mapa e orientação" kicker="GEOGRAFIA" subtitle="Uma visão simplificada para localizar regiões e pontos importantes.">
   <div className="map">
    <div className="map-label westeros">WESTEROS</div><div className="map-label essos">ESSOS</div>
    <button className="pin winterfell" onClick={()=>navigate("place:winterfell")}>Winterfell</button>
    <button className="pin wall" onClick={()=>navigate("place:wall")}>Muralha</button>
    <button className="pin kings" onClick={()=>navigate("place:kings-landing")}>Porto Real</button>
   </div>
   <div className="place-grid">{places.map(p=><article className="place" key={p.id}><span className="eyebrow">{p.type}</span><h3>{p.name}</h3><p>{p.description}</p></article>)}</div>
 </Page>
}

export function PlaceDetail({id,navigate}) {
 const p=places.find(x=>x.id===id);
 return <Page title={p?.name||"Local não encontrado"} kicker={p?.type||"ERRO"} subtitle={p?.description}><button className="secondary" onClick={()=>navigate("map")}>← Voltar para o mapa</button></Page>
}