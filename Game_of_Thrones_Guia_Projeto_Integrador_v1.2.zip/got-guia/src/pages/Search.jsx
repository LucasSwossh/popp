import { characters,houses,places,concepts } from "../data/data";
import { Page } from "./Fundamentals";
import { EntityCard } from "../components/Card";
export default function Search({q,navigate}) {
 const term=(q||"").trim().toLowerCase();
 const all=[
  ...characters.map(x=>({...x,type:"Personagem",description:`${x.role} · ${x.house}`})),
  ...houses.map(x=>({...x,type:"Casa"})),
  ...places.map(x=>({...x,type:"Lugar"})),
  ...concepts.map(x=>({...x,type:x.type}))
 ];
 const result=term?all.filter(x=>`${x.name} ${x.description||""}`.toLowerCase().includes(term)):all.slice(0,8);
 return <Page title="Busca universal" kicker="PESQUISA" subtitle={term?`Resultados para “${q}”`:"Pesquise personagens, Casas, lugares, títulos, grupos e conceitos."}>
  {!term&&<div className="notice"><b>Dica</b><p>Use a barra de busca no topo para procurar qualquer entidade.</p></div>}
  <div className="card-grid">{result.map(x=><EntityCard key={`${x.type}-${x.id}`} item={x} onClick={()=>{
    if(x.type==="Personagem") navigate("character:"+x.id);
    else if(x.type==="Casa") navigate("house:"+x.id);
    else if(x.type==="Lugar") navigate("place:"+x.id);
    else navigate("glossary");
  }}/>)}</div>
  {term&&!result.length&&<div className="empty">Nenhum resultado encontrado. Tente outro nome ou termo.</div>}
 </Page>
}