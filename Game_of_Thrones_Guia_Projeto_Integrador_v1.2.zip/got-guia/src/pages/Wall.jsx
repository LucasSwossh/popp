import { Page } from "./Fundamentals";
export default function Wall() {
 return <Page title="Muralha e Patrulha da Noite" kicker="NORTE" subtitle="A Muralha e a Patrulha fazem parte fundamental da compreensão do mundo apresentado no início.">
  <div className="timeline">
   <article><span>01</span><div><h3>O que é a Muralha?</h3><p>Uma enorme fortificação no extremo norte de Westeros.</p></div></article>
   <article><span>02</span><div><h3>Qual é sua função?</h3><p>Separar e proteger a fronteira norte dos Sete Reinos.</p></div></article>
   <article><span>03</span><div><h3>Quem é a Patrulha da Noite?</h3><p>Uma ordem que guarnece a Muralha e cumpre sua missão de proteção.</p></div></article>
   <article><span>04</span><div><h3>Onde seus membros atuam?</h3><p>Na Muralha e nas áreas ligadas à sua missão, dentro do recorte inicial.</p></div></article>
  </div>
 </Page>
}