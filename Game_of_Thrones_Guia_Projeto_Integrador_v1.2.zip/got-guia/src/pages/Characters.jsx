import { useMemo, useState } from "react";
import { characters } from "../data/data";
import { CharacterCard } from "../components/Card";
import { Page } from "./Fundamentals";

export default function Characters({ navigate }) {
  const [q,setQ]=useState(""); const [level,setLevel]=useState("Todos");
  const filtered=useMemo(()=>characters.filter(c=>(level==="Todos"||c.level===level)&&`${c.name} ${c.house} ${c.role} ${c.place}`.toLowerCase().includes(q.toLowerCase())),[q,level]);
  return <Page title="Quem é quem?" kicker="PERSONAGENS" subtitle="Catálogo pesquisável de personagens relevantes para o início da história.">
    <div className="toolbar"><input className="big-input" value={q} onChange={e=>setQ(e.target.value)} placeholder="🔎 Pesquisar personagem, Casa ou função..." />
      <select value={level} onChange={e=>setLevel(e.target.value)}><option>Todos</option><option>Essencial</option><option>Importante</option><option>Contextual</option></select>
    </div>
    <p className="result-count">{filtered.length} resultado(s)</p>
    <div className="card-grid">{filtered.map(c=><CharacterCard key={c.id} character={c} onClick={()=>navigate("character:"+c.id)}/>)}</div>
  </Page>
}

export function CharacterDetail({id,navigate}) {
 const c=characters.find(x=>x.id===id);
 if(!c)return <Page title="Personagem não encontrado" kicker="ERRO"/>;
 return <Page title={c.name} kicker={c.level} subtitle={c.memory}>
   <div className="profile"><div className="profile-avatar">{c.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</div><div><p><b>Casa/grupo:</b> {c.house}</p><p><b>Função:</b> {c.role}</p><p><b>Localização no contexto:</b> {c.place}</p></div></div>
   <div className="notice"><b>Gancho de memória</b><p>{c.memory}</p></div>
   <button className="secondary" onClick={()=>navigate("characters")}>← Voltar para personagens</button>
 </Page>
}