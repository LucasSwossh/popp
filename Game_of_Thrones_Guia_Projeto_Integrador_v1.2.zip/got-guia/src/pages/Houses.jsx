import { houses, characters } from "../data/data";
import { HouseCard } from "../components/Card";
import { Page } from "./Fundamentals";

export default function Houses({ navigate }) {
  return <Page title="Casas" kicker="EXPLORAÇÃO" subtitle="Casas são unidades sociais, territoriais e políticas. Explore seus membros e contexto inicial.">
    <div className="card-grid">{houses.map(h=><HouseCard key={h.id} house={h} onClick={()=>navigate("house:"+h.id)}/>)}</div>
  </Page>
}

export function HouseDetail({ id, navigate }) {
  const house = houses.find(h=>h.id===id);
  const members = characters.filter(c=>c.house===house?.name);
  if(!house) return <Page title="Casa não encontrada" kicker="ERRO"><button className="primary" onClick={()=>navigate("houses")}>Voltar</button></Page>;
  return <Page title={house.name} kicker="CASA" subtitle={house.summary}>
    <div className="detail-hero"><div className="big-sigil">♜</div><div><h2>“{house.motto}”</h2><p><b>Região:</b> {house.region} · <b>Sede:</b> {house.seat}</p></div></div>
    <h2 className="subheading">Personagens relacionados</h2>
    <div className="card-grid">{members.length ? members.map(c=><div className="card" key={c.id}><span className="eyebrow">{c.level}</span><h3>{c.name}</h3><p>{c.role}</p></div>) : <p>Nenhum personagem cadastrado nesta versão.</p>}</div>
  </Page>
}