import { familyRelations } from "../data/data";
import { Page } from "./Fundamentals";

export default function Relations() {
  const groups = [...new Set(familyRelations.map(r => r.label))];
  return <Page
    title="Famílias e relações"
    kicker="CONEXÕES"
    subtitle="Uma visão rápida de parentesco e vínculos para responder: quem é ligado a quem?"
  >
    <div className="relation-intro">
      <div className="relation-node">PERSONAGEM</div>
      <div className="relation-arrow">↕</div>
      <div className="relation-node">RELAÇÃO</div>
      <div className="relation-arrow">↕</div>
      <div className="relation-node">PERSONAGEM</div>
    </div>
    {groups.map(group => <section className="relation-group" key={group}>
      <span className="eyebrow">{group}</span>
      <div className="relation-list">
        {familyRelations.filter(r=>r.label===group).map((r,i)=>
          <div className="relation-row" key={i}>
            <strong>{r.from}</strong><span>↔</span><strong>{r.to}</strong>
          </div>
        )}
      </div>
    </section>)}
  </Page>
}
