export default function Fundamentals({ navigate }) {
  const topics = [
    ["Westeros","O continente onde ficam os Sete Reinos e grande parte da história inicial.","westeros"],
    ["Essos","Continente a leste de Westeros. No início, Daenerys e Viserys estão lá.","essos"],
    ["Sete Reinos","Forma tradicional de se referir ao reino governado pelo Trono de Ferro.","seven-kingdoms"],
    ["Trono de Ferro","Símbolo do poder real e assento do rei dos Sete Reinos.","iron-throne"],
    ["Grandes Casas","Famílias nobres de grande importância política e territorial.","great-houses"],
    ["Norte e Sul","Regiões e identidades territoriais ajudam a entender onde as Casas estão inseridas.","north-south"]
  ];
  return <Page title="Começando do zero" kicker="FUNDAMENTOS" subtitle="Primeiro entenda o mundo. Depois, os nomes começam a fazer sentido.">
    <div className="learning-list">{topics.map(([title,text,id],i)=><article className="learn-item" key={id}><span>{String(i+1).padStart(2,"0")}</span><div><h3>{title}</h3><p>{text}</p></div></article>)}</div>
    <div className="notice"><b>Como usar o guia</b><p>Você não precisa memorizar tudo. Use a busca e as conexões sempre que surgir uma dúvida.</p></div>
  </Page>
}

export function Page({title,kicker,subtitle,children}) {
  return <main className="page"><span className="eyebrow">{kicker}</span><h1>{title}</h1>{subtitle&&<p className="lead">{subtitle}</p>}{children}</main>
}