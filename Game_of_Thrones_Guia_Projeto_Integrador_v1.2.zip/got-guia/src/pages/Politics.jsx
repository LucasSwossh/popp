import { concepts } from "../data/data";
import { Page } from "./Fundamentals";
export default function Politics() {
 const items=concepts.filter(x=>["Título","Conceito"].includes(x.type));
 return <Page title="Poder, política e títulos" kicker="PODER" subtitle="Entenda as estruturas básicas sem transformar o guia em uma aula excessivamente acadêmica.">
  <div className="card-grid">{items.map(x=><article className="card" key={x.id}><span className="eyebrow">{x.type}</span><h3>{x.name}</h3><p>{x.description}</p><div className="meta">Por que importa: ajuda a entender as relações de poder apresentadas no início.</div></article>)}</div>
 </Page>
}