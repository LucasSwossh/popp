import Lost from "../components/Lost";
import { houses, characters, places, concepts } from "../data/data";
import { HouseCard, CharacterCard } from "../components/Card";

export default function Home({ navigate }) {
  return <>
    <div className="spoiler-strip"><span>🛡️</span><div><b>GUIA SEM SPOILERS</b><small>Conteúdo pensado para quem está começando a 1ª temporada.</small></div></div>
    <section className="hero">
      <div className="hero-copy">
        <span className="eyebrow">UM GUIA PARA QUEM ESTÁ COMEÇANDO</span>
        <h1>Agora você entende<br/><em>quem é quem.</em></h1>
        <p>Aprenda o básico sobre Westeros, Casas, personagens, lugares e poder — com uma experiência pensada para o início da história.</p>
        <div className="actions">
          <button className="primary" onClick={()=>navigate("fundamentals")}>Começar pelo básico →</button>
          <button className="secondary" onClick={()=>navigate("lost")}>Estou perdido</button>
        </div>
      </div>
      <div className="hero-emblem"><div>♜</div><small>SEM SPOILERS<br/>DO FUTURO</small></div>
    </section>

    <section className="stats-strip">
      <div><strong>{houses.length}</strong><span>Casas cadastradas</span></div>
      <div><strong>{characters.length}</strong><span>Personagens</span></div>
      <div><strong>{places.length}</strong><span>Lugares</span></div>
      <div><strong>{concepts.length}</strong><span>Conceitos</span></div>
    </section>

    <section className="section">
      <div className="section-head"><div><span className="eyebrow">COMECE AQUI</span><h2>Três caminhos</h2></div></div>
      <div className="path-grid">
        <button onClick={()=>navigate("fundamentals")}><span>01</span><h3>Quero aprender</h3><p>Entenda o mundo antes de entrar nos detalhes.</p>→</button>
        <button onClick={()=>navigate("characters")}><span>02</span><h3>Estou assistindo</h3><p>Consulte rapidamente uma pessoa, Casa ou lugar.</p>→</button>
        <button onClick={()=>navigate("search")}><span>03</span><h3>Quero entender melhor</h3><p>Pesquise uma dúvida específica.</p>→</button>
      </div>
    </section>

    <section className="section dark-section">
      <div className="section-head"><div><span className="eyebrow">EXPLORAÇÃO</span><h2>Conheça as principais Casas</h2></div><button className="text-btn" onClick={()=>navigate("houses")}>Ver todas →</button></div>
      <div className="card-grid">{houses.slice(0,3).map(h=><HouseCard key={h.id} house={h} onClick={()=>navigate("houses")}/>)}</div>
    </section>

    <section className="section">
      <div className="section-head"><div><span className="eyebrow">CONSULTA RÁPIDA</span><h2>Quem é quem?</h2></div><button className="text-btn" onClick={()=>navigate("characters")}>Ver personagens →</button></div>
      <div className="card-grid">{characters.slice(0,4).map(c=><CharacterCard key={c.id} character={c} onClick={()=>navigate("characters")}/>)}</div>
    </section>
    <Lost navigate={navigate}/>
  </>
}