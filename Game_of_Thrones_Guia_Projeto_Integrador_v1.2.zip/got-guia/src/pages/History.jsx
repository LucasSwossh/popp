import { Page } from "./Fundamentals";
export default function History() {
 return <Page title="Antes da série" kicker="CONTEXTO" subtitle="Somente o passado necessário para compreender a situação apresentada no começo.">
  <div className="notice"><b>Regra deste módulo</b><p>Não avançamos para destinos, mortes, traições, revelações ou acontecimentos posteriores.</p></div>
  <div className="learning-list">
   <article className="learn-item"><span>01</span><div><h3>Mudança de poder</h3><p>Houve uma mudança de poder antes do início da história, e o presente é marcado pelas consequências políticas desse passado.</p></div></article>
   <article className="learn-item"><span>02</span><div><h3>Os Targaryen</h3><p>A Casa Targaryen não ocupa o poder no presente do início da série. Daenerys e Viserys estão fora de Westeros.</p></div></article>
   <article className="learn-item"><span>03</span><div><h3>Por que o passado importa?</h3><p>Referências à história anterior ajudam a compreender as tensões e relações apresentadas no começo.</p></div></article>
  </div>
 </Page>
}