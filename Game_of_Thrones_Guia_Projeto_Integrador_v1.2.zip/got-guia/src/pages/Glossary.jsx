import { useState } from "react";
import { concepts } from "../data/data";
import { Page } from "./Fundamentals";
export default function Glossary() {
 const [q,setQ]=useState("");
 const list=concepts.filter(x=>x.name.toLowerCase().includes(q.toLowerCase())||x.description.toLowerCase().includes(q.toLowerCase()));
 return <Page title="Glossário" kicker="CONSULTA RÁPIDA" subtitle="Termos, títulos, organizações, lugares e conceitos em explicações curtas.">
  <input className="big-input" value={q} onChange={e=>setQ(e.target.value)} placeholder="🔎 Pesquisar termo..." />
  <div className="glossary">{list.map(x=><article key={x.id}><span>{x.type}</span><div><h3>{x.name}</h3><p>{x.description}</p></div></article>)}</div>
 </Page>
}