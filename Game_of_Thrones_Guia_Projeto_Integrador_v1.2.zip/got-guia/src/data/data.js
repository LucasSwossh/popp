export const houses = [
  { id:"stark", name:"Casa Stark", motto:"O inverno está chegando.", region:"Norte", seat:"Winterfell", summary:"Uma das Grandes Casas associadas ao Norte de Westeros." },
  { id:"lannister", name:"Casa Lannister", motto:"Ouça-me rugir!", region:"Terras Ocidentais", seat:"Rochedo Casterly", summary:"Uma das Grandes Casas de Westeros, ligada a grande riqueza e influência." },
  { id:"baratheon", name:"Casa Baratheon", motto:"Nossa é a fúria.", region:"Terras da Coroa", seat:"Ponta Tempestade", summary:"Casa ligada à família real no início da série." },
  { id:"targaryen", name:"Casa Targaryen", motto:"Fogo e sangue.", region:"Contexto histórico", seat:"—", summary:"Família que governou Westeros antes da mudança de poder anterior ao início da série." },
  { id:"arryn", name:"Casa Arryn", motto:"Tão alto quanto a honra.", region:"Vale", seat:"Ninho da Águia", summary:"Grande Casa associada ao Vale de Arryn." },
  { id:"tully", name:"Casa Tully", motto:"Família, dever, honra.", region:"Terras Fluviais", seat:"Correrrio", summary:"Grande Casa associada às Terras Fluviais." }
];

export const characters = [
  { id:"eddard", name:"Eddard Stark", house:"Casa Stark", role:"Lorde de Winterfell", place:"Winterfell", level:"Essencial", memory:"O líder da Casa Stark no início da história.", related:["stark","winterfell"] },
  { id:"catelyn", name:"Catelyn Stark", house:"Casa Stark", role:"Senhora de Winterfell", place:"Winterfell", level:"Importante", memory:"Matriarca da família Stark.", related:["stark","winterfell"] },
  { id:"jon", name:"Jon Snow", house:"Ligação com a Casa Stark", role:"Recruta da Patrulha da Noite", place:"Muralha", level:"Essencial", memory:"Jovem que segue para a Patrulha da Noite.", related:["night-watch","wall"] },
  { id:"rob", name:"Robb Stark", house:"Casa Stark", role:"Herdeiro de Winterfell", place:"Winterfell", level:"Importante", memory:"Filho mais velho de Eddard e Catelyn.", related:["stark","winterfell"] },
  { id:"sansa", name:"Sansa Stark", house:"Casa Stark", role:"Membro da família Stark", place:"Winterfell", level:"Essencial", memory:"Filha de Eddard e Catelyn.", related:["stark","winterfell"] },
  { id:"arya", name:"Arya Stark", house:"Casa Stark", role:"Membro da família Stark", place:"Winterfell", level:"Essencial", memory:"Filha de Eddard e Catelyn, com personalidade independente.", related:["stark","winterfell"] },
  { id:"bran", name:"Bran Stark", house:"Casa Stark", role:"Membro da família Stark", place:"Winterfell", level:"Essencial", memory:"Um dos filhos mais novos de Eddard e Catelyn.", related:["stark","winterfell"] },
  { id:"tyrion", name:"Tyrion Lannister", house:"Casa Lannister", role:"Membro da família Lannister", place:"Westeros", level:"Essencial", memory:"Lannister conhecido por sua inteligência e humor.", related:["lannister"] },
  { id:"jaime", name:"Jaime Lannister", house:"Casa Lannister", role:"Cavaleiro da Guarda Real", place:"Porto Real", level:"Importante", memory:"Membro da Casa Lannister e da Guarda Real.", related:["lannister","kings-landing"] },
  { id:"cersei", name:"Cersei Lannister", house:"Casa Lannister", role:"Rainha", place:"Porto Real", level:"Essencial", memory:"Rainha no início da série e membro da Casa Lannister.", related:["lannister","kings-landing"] },
  { id:"robert", name:"Robert Baratheon", house:"Casa Baratheon", role:"Rei dos Sete Reinos", place:"Porto Real", level:"Essencial", memory:"Rei no início da história.", related:["baratheon","kings-landing"] },
  { id:"daenerys", name:"Daenerys Targaryen", house:"Casa Targaryen", role:"Membro da família Targaryen", place:"Essos", level:"Essencial", memory:"Jovem Targaryen vivendo fora de Westeros.", related:["targaryen","essos"] },
  { id:"viserys", name:"Viserys Targaryen", house:"Casa Targaryen", role:"Membro da família Targaryen", place:"Essos", level:"Importante", memory:"Irmão de Daenerys.", related:["targaryen","essos"] }
];

export const places = [
  { id:"westeros", name:"Westeros", type:"Continente", description:"Continente onde estão os Sete Reinos e grande parte do cenário inicial." },
  { id:"essos", name:"Essos", type:"Continente", description:"Continente a leste de Westeros, onde vivem Daenerys e Viserys no início." },
  { id:"winterfell", name:"Winterfell", type:"Castelo", description:"Sede da Casa Stark e centro importante do Norte." },
  { id:"kings-landing", name:"Porto Real", type:"Cidade", description:"Capital dos Sete Reinos e local do Trono de Ferro." },
  { id:"wall", name:"A Muralha", type:"Estrutura", description:"Grande fortificação no extremo norte de Westeros, guardada pela Patrulha da Noite." }
];

export const concepts = [
  { id:"iron-throne", name:"Trono de Ferro", type:"Conceito", description:"Símbolo do poder real e assento do rei dos Sete Reinos." },
  { id:"great-houses", name:"Grandes Casas", type:"Conceito", description:"Casas nobres de grande importância política e territorial." },
  { id:"hand", name:"Mão do Rei", type:"Título", description:"Cargo de grande responsabilidade que auxilia o rei na administração do reino." },
  { id:"warden-north", name:"Guardião do Norte", type:"Título", description:"Título ligado à autoridade e proteção do Norte." },
  { id:"night-watch", name:"Patrulha da Noite", type:"Grupo", description:"Ordem que guarnece a Muralha e protege a fronteira norte." },
  { id:"seven-kingdoms", name:"Sete Reinos", type:"Conceito", description:"Forma tradicional de se referir ao reino governado pelo Trono de Ferro." }
];

export const relations = [
  ["Eddard Stark","Casa Stark"],["Catelyn Stark","Casa Stark"],["Robb Stark","Casa Stark"],
  ["Sansa Stark","Casa Stark"],["Arya Stark","Casa Stark"],["Bran Stark","Casa Stark"],
  ["Jon Snow","Patrulha da Noite"],["Robert Baratheon","Trono de Ferro"],
  ["Cersei Lannister","Casa Lannister"],["Jaime Lannister","Casa Lannister"],
  ["Tyrion Lannister","Casa Lannister"],["Daenerys Targaryen","Casa Targaryen"]
];


export const familyRelations = [
  { from:"Eddard Stark", to:"Catelyn Stark", label:"casamento" },
  { from:"Eddard Stark", to:"Robb Stark", label:"pai" },
  { from:"Eddard Stark", to:"Sansa Stark", label:"pai" },
  { from:"Eddard Stark", to:"Arya Stark", label:"pai" },
  { from:"Eddard Stark", to:"Bran Stark", label:"pai" },
  { from:"Catelyn Stark", to:"Robb Stark", label:"mãe" },
  { from:"Catelyn Stark", to:"Sansa Stark", label:"mãe" },
  { from:"Catelyn Stark", to:"Arya Stark", label:"mãe" },
  { from:"Catelyn Stark", to:"Bran Stark", label:"mãe" },
  { from:"Robb Stark", to:"Sansa Stark", label:"irmãos" },
  { from:"Robb Stark", to:"Arya Stark", label:"irmãos" },
  { from:"Robb Stark", to:"Bran Stark", label:"irmãos" },
  { from:"Sansa Stark", to:"Arya Stark", label:"irmãs" },
  { from:"Arya Stark", to:"Bran Stark", label:"irmãos" },
  { from:"Daenerys Targaryen", to:"Viserys Targaryen", label:"irmãos" },
  { from:"Cersei Lannister", to:"Jaime Lannister", label:"irmãos" },
  { from:"Cersei Lannister", to:"Tyrion Lannister", label:"irmãos" },
  { from:"Jaime Lannister", to:"Tyrion Lannister", label:"irmãos" }
];

export const spoilerPolicy = [
  "O guia considera o ponto de vista de alguém que está começando a 1ª temporada.",
  "Não são apresentados destinos, mortes, traições, romances ou revelações futuras.",
  "Filtros, busca, relações e microtextos seguem o mesmo recorte.",
  "Quando uma informação não é necessária para compreender o início, ela fica fora do guia."
];
