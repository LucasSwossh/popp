import { useState } from "react";

export default function Header({ navigate, search, setSearch }) {
  const [open, setOpen] = useState(false);
  const go = (page) => { navigate(page); setOpen(false); };

  return <header className="header">
    <div className="brand" onClick={() => go("home")}>
      <span className="brand-mark">✦</span>
      <span><b>GAME OF THRONES</b><small>GUIA PARA NÃO SE PERDER</small></span>
    </div>
    <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Abrir menu">☰</button>
    <nav className={open ? "nav open" : "nav"}>
      {[
        ["home","Início"],["fundamentals","Começando"],["houses","Casas"],
        ["characters","Personagens"],["map","Mapa"],["politics","Poder"],
        ["wall","Muralha"],["history","Antes da série"],["relations","Relações"],["glossary","Glossário"]
      ].map(([id,label]) => <button key={id} onClick={() => go(id)}>{label}</button>)}
    </nav>
    <div className="header-search">
      <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key==="Enter" && go("search")} placeholder="Buscar..." aria-label="Busca universal" />
      <button onClick={() => go("search")}>⌕</button>
    </div>
  </header>
}