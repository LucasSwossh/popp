export default function Lost({ navigate }) {
  const options = [
    ["characters","👤","Uma pessoa"],["houses","♜","Uma Casa"],["map","🗺","Um lugar"],
    ["politics","♛","Um título ou poder"],["relations","🔗","Uma relação"],["glossary","📖","Um conceito"],["history","⌛","Algo do passado"]
  ];
  return <section className="lost-panel">
    <span className="eyebrow">ORIENTAÇÃO</span><h2>Está perdido?</h2>
    <p>Escolha o tipo de dúvida e vamos levar você para o lugar certo.</p>
    <div className="lost-grid">{options.map(([page,icon,label]) =>
      <button key={page} onClick={()=>navigate(page)}><strong>{icon}</strong>{label}<span>→</span></button>
    )}</div>
  </section>
}