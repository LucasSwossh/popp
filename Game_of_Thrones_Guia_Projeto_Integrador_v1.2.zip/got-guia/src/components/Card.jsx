export function HouseCard({ house, onClick }) {
  return <article className="card clickable" onClick={onClick}>
    <div className="sigil">♜</div><span className="eyebrow">CASA</span>
    <h3>{house.name}</h3><p className="motto">“{house.motto}”</p>
    <p>{house.summary}</p><div className="meta">{house.region} · {house.seat}</div>
  </article>
}

export function CharacterCard({ character, onClick }) {
  return <article className="card clickable" onClick={onClick}>
    <div className="avatar">{character.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</div>
    <span className="eyebrow">{character.level}</span><h3>{character.name}</h3>
    <p>{character.role}</p><div className="meta">{character.house} · {character.place}</div>
  </article>
}

export function EntityCard({ item, onClick }) {
  return <article className="card clickable" onClick={onClick}>
    <span className="eyebrow">{item.type || "ENTIDADE"}</span><h3>{item.name}</h3><p>{item.description}</p>
  </article>
}