import { useState } from "react";
import Header from "./components/Header";
import Home from "./pages/Home";
import { Page } from "./pages/Fundamentals";
import Fundamentals from "./pages/Fundamentals";
import Houses,{HouseDetail} from "./pages/Houses";
import Characters,{CharacterDetail} from "./pages/Characters";
import MapPage,{PlaceDetail} from "./pages/MapPage";
import Politics from "./pages/Politics";
import Wall from "./pages/Wall";
import History from "./pages/History";
import Glossary from "./pages/Glossary";
import Relations from "./pages/Relations";
import Search from "./pages/Search";
import Lost from "./components/Lost";

export default function App(){
 const [page,setPage]=useState("home"); const [search,setSearch]=useState("");
 const navigate=(p)=>{setPage(p); window.scrollTo({top:0,behavior:"smooth"})};
 let content;
 if(page==="home")content=<Home navigate={navigate}/>;
 else if(page==="fundamentals")content=<Fundamentals navigate={navigate}/>;
 else if(page==="houses")content=<Houses navigate={navigate}/>;
 else if(page.startsWith("house:"))content=<HouseDetail id={page.split(":")[1]} navigate={navigate}/>;
 else if(page==="characters")content=<Characters navigate={navigate}/>;
 else if(page.startsWith("character:"))content=<CharacterDetail id={page.split(":")[1]} navigate={navigate}/>;
 else if(page==="map")content=<MapPage navigate={navigate}/>;
 else if(page.startsWith("place:"))content=<PlaceDetail id={page.split(":")[1]} navigate={navigate}/>;
 else if(page==="politics")content=<Politics/>;
 else if(page==="wall")content=<Wall/>;
 else if(page==="history")content=<History/>;
 else if(page==="glossary")content=<Glossary/>;
 else if(page==="relations")content=<Relations/>;
 else if(page==="search")content=<Search q={search} navigate={navigate}/>;
 else if(page==="lost")content=<Page title="Estou perdido" kicker="ORIENTAÇÃO"><Lost navigate={navigate}/></Page>;
 else content=<Page title="Página não encontrada" kicker="404"><button className="primary" onClick={()=>navigate("home")}>Voltar ao início</button></Page>;
 return <div className="app"><Header navigate={navigate} search={search} setSearch={setSearch}/><div className="content">{content}</div><footer><div><b>GAME OF THRONES</b><span>GUIA PARA NÃO SE PERDER</span></div><p>Projeto Integrador · Guia educativo para iniciantes · Zero spoilers</p></footer></div>
}