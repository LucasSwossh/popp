# Game of Thrones — Guia para não se perder

Projeto Integrador — aplicação web educativa e interativa para quem está começando a 1ª temporada de Game of Thrones.

## Tecnologias
- React
- Vite
- JavaScript
- CSS
- Dados locais em JavaScript

## Executar
```bash
npm install
npm run dev
```

Depois abra o endereço exibido pelo Vite.

## Build
```bash
npm run build
```

## Organização
- `src/components`: componentes reutilizáveis
- `src/data`: dados das entidades
- `src/pages`: módulos do projeto
- `src/App.jsx`: navegação e integração

## Regra editorial
O conteúdo desta versão foi estruturado para o recorte inicial da 1ª temporada. Antes da entrega, revise o conteúdo com o grupo/professor para validar a política de zero spoilers.

## Módulos adicionados na versão 1.1
- Famílias e relações visuais
- Navegação dedicada para relações
- Faixa de aviso de zero spoilers
- Orientação "Estou perdido" ampliada


## Checklist de apresentação

Durante a demonstração, siga este fluxo curto:
1. Abra a Home e mostre o aviso de zero spoilers.
2. Entre em Começando e explique Westeros, Trono de Ferro e Grandes Casas.
3. Abra Casas e entre em uma Casa para mostrar navegação por entidade.
4. Abra Personagens e use a pesquisa/filtro.
5. Abra Relações para demonstrar conexões familiares.
6. Abra Mapa e mostre Winterfell, Muralha e Porto Real.
7. Abra Poder e Muralha para demonstrar os módulos temáticos.
8. Use a busca universal e finalize com Estou perdido.

## Critério de conteúdo

A interface foi construída para que o aluno consiga consultar uma informação sem precisar decorar os nomes. O conteúdo apresentado deve continuar restrito ao recorte inicial/sem spoilers definido para o projeto.
